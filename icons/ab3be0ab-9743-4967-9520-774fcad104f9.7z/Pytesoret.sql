-- RIFRESKIMI I KOMANDAVE PERMES: CTRL + SHIFT + R

-- 1 Insertimi i shenimeve duke definuar kolonat
INSERT [dbo].[Filmat] 
([Titulli], [Viti], [Regjisori], [Cmimi], [IDFormati])
VALUES
('Titulli Filmit', 2020, 'Emri Regjisorit', 10.2, 2)

-- 2 Insertimi i shenimeve pa bere definimin e kolonave
INSERT [dbo].[Filmat] 
VALUES
('Titulli Filmit 3', 2020, 'Emri Regjisorit 3', 10.2, 2)

-- 3 Insertimi i shenimeve masive
INSERT [dbo].[Filmat] 
VALUES
('Titulli Filmit 4', 2020, 'Emri Regjisorit 4', 2, 2),
('Titulli Filmit 5', 2016, 'Emri Regjisorit 5', 4, 1),
('Titulli Filmit 6', 2019, 'Emri Regjisorit 6', 3, 2),
('Titulli Filmit 7', 2014, 'Emri Regjisorit 7', 4, 3),
('Titulli Filmit 8', 2013, 'Emri Regjisorit 8', 1, 3),
('Titulli Filmit 9', 2002, 'Emri Regjisorit 9', 7.2, 1)

-- 4 Insertimi i filmave nga tabela FilmatPremiere ne tabelen Filmat

INSERT	[dbo].[Filmat] ([Titulli], [Viti], [Regjisori], [Cmimi], [IDFormati])
SELECT	[Titulli], [Viti], [Regjisori], [Cmimi], [IDFormati]
FROM	[dbo].[FilmatPremiere]
WHERE	[DataLansimit] = '2020-04-17 00:00:00.000'

-- 5 Insertimi i filmave nga tabela FilmatPremiere ne tabelen Filmat duke parsuar daten

INSERT	[dbo].[Filmat] ([Titulli], [Viti], [Regjisori], [Cmimi], [IDFormati])
SELECT	[Titulli], [Viti], [Regjisori], [Cmimi], [IDFormati]
FROM	[dbo].[FilmatPremiere]
WHERE	CAST([DataLansimit] AS DATE) = CAST('2020-04-17' AS DATE)

-- 6 Leximi i filmave me te gjitha kolonat nga tabela Filmat qe kane cmim me te ulet se 5 EUR dhe qe jane te formatit DVD
SELECT	*
FROM	Filmat
WHERE	Cmimi < 5 AND IDFormati = 2


-- 6 Leximi i filmave me kolonat Titulli dhe Viti nga tabela Filmat qe kane cmim me te ulet se 5 EUR dhe qe jane te formatit DVD
SELECT	Titulli, Viti
FROM	Filmat
WHERE	Cmimi < 5 AND IDFormati = 2

-- 7 Leximi i filmave qe jane te formatit Blue Ray permes tekstit
SELECT	*
FROM	Filmat
WHERE   IDFormati = (SELECT ID FROM Formati WHERE Titulli = 'Blue Ray')

-- 8 Leximi i filmave qe jane te formatit DVD dhe CD dhe renditja sipas formatit nga ma e vogla tek me e madhja

SELECT		* 
FROM		Filmat
WHERE		IDFormati IN (1, 2)
ORDER BY	IDFormati ASC 

-- 9 Leximi i filmave qe jane te formatit DVD dhe CD dhe renditja sipas formatit nga ma e vogla tek me e madhja dhe cmimit

SELECT		* 
FROM		Filmat
WHERE		IDFormati IN (SELECT ID FROM Formati WHERE Titulli IN ('CD', 'DVD'))
ORDER BY	IDFormati, Cmimi ASC 


-- 10 Perditesimi i filmave qe e kane cmimin 20 EUR. Keta filma dueht te zbriten ne 17 EUR

UPDATE		Filmat
SET			Cmimi = 17
WHERE		Cmimi = 20


-- 11 Perditesimi i filmave qe e kane cmimin 20 EUR dhe mbi, por jo me larte se 21 EUR. Keta filma dueht te zbriten ne 17 EUR

UPDATE		Filmat
SET			Cmimi = 17
WHERE		Cmimi >= 20 AND Cmimi < 21


-- 12 Fshirja e filmave nga FilmatPremiere te dates  17-04-2020

DELETE 
FROM		FilmatPremiere
WHERE		DataLansimit = '2020-04-17 00:00:00.000'


